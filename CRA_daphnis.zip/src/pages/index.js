import React from "react";
import theme from "theme";
import { Theme, Image, Link, Button, Section, Strong, Text, Box } from "@quarkly/widgets";
import { Helmet } from "react-helmet";
import { GlobalQuarklyPageStyles } from "global-page-styles";
import { Override, SocialMedia } from "@quarkly/components";
import * as Components from "components";
import { MdMenu } from "react-icons/md";
export default (() => {
	return <Theme theme={theme}>
		<GlobalQuarklyPageStyles pageUrl={"index"} />
		<Helmet>
			<title>
				Home | Website Example
			</title>
			<meta name={"description"} content={"It all begins with an idea. Maybe you want to launch a business. Maybe you want to turn a hobby into something bigger. Or maybe you have a creative project to share with the world. Whatever it is, the way you tell your story online can make all the difference."} />
			<meta property={"og:title"} content={"Home | Website Example"} />
			<meta property={"og:description"} content={"It all begins with an idea. Maybe you want to launch a business. Maybe you want to turn a hobby into something bigger. Or maybe you have a creative project to share with the world. Whatever it is, the way you tell your story online can make all the difference."} />
			<meta property={"og:image"} content={"https://uploads.quarkly.io/5f44d0da669357001e60ed14/images/website-example-quarkly.png?v=2020-11-05T19:48:01.806Z"} />
			<link rel={"shortcut icon"} href={"https://uploads.quarkly.io/readme/cra/favicon-32x32.ico"} type={"image/x-icon"} />
		</Helmet>
		<Section padding="16px 0 16px 0" quarkly-title="Header" align-items="center" justify-content="center">
			<Override
				slot="SectionContent"
				md-margin="0px 16px 0px 16px"
				display="grid"
				grid-template-columns="repeat(3, 1fr)"
				md-grid-template-columns="repeat(2, 1fr)"
				margin="0px 32px 0px 32px"
				width="100%"
			/>
			<Link transition="opacity 200ms ease" quarkly-title="Link" href="/" position="relative">
				<Image src="https://uploads.quarkly.io/5f44d0da669357001e60ed14/images/default-website-logo.svg?v=2020-11-06T17:26:21.226Z" width="120px" z-index="3" />
			</Link>
			<Components.BurgerMenu md-display="flex" md-align-items="center" md-justify-content="flex-end">
				<Override slot="icon-open" md-position="fixed" md-top="18px" md-right="18px" />
				<Override
					slot="menu"
					md-top={0}
					md-width="100%"
					justify-content="center"
					lg-transition="transform 400ms ease 0s"
					md-position="fixed"
					display="flex"
					md-left={0}
					lg-transform="translateY(0px) translateX(0px)"
					md-height="100%"
					padding="0px 0 0px 0"
					align-items="center"
				>
					<Override
						slot="item"
						md-padding="16px 40px 16px 40px"
						display="inline-block"
						text-transform="uppercase"
						text-align="center"
						padding="8px 20px 8px 20px"
					/>
					<Override slot="item-404" lg-display="none" display="none" />
					<Override slot="item-index" lg-display="none" display="none" />
					<Override
						slot="link"
						md-hover-opacity="1"
						md-active-opacity="1"
						md-color="--dark"
						font="--base"
						text-transform="initial"
						md-font="16px/24px sans-serif"
						text-decoration-line="initial"
						color="--dark"
						transition="opacity .15s ease 0s"
						letter-spacing="0.5px"
						md-opacity=".5"
						md-transition="opacity .15s ease 0s"
						opacity=".5"
						hover-opacity="1"
					/>
					<Override
						slot="link-active"
						md-opacity="1"
						md-cursor="default"
						opacity="1"
						color="--primary"
						cursor="default"
					/>
				</Override>
				<Override slot="icon,icon-close" category="md" icon={MdMenu} />
				<Override
					slot="icon"
					category="md"
					icon={MdMenu}
					size="36px"
					md-right="0px"
					md-position="relative"
				/>
				<Override
					slot="menu-open"
					md-justify-content="center"
					md-top={0}
					md-bottom={0}
					md-display="flex"
					md-flex-direction="column"
					md-align-items="center"
				/>
			</Components.BurgerMenu>
			<Button
				md-display="none"
				white-space="nowrap"
				transition="transform --transitionDuration-fast --transitionTimingFunction-easeInOut 0s"
				font="--base"
				letter-spacing="0.5px"
				z-index="5"
				background="--color-primary"
				padding="8px 18px 8px 18px"
				border-radius="0px"
				hover-transform="translateY(-4px)"
				justify-self="end"
			>
				Contact Us
			</Button>
		</Section>
		<Section
			lg-padding="25px 0 25px 0"
			sm-padding="0px 0 25px 0"
			justify-content="center"
			padding="25px 0 75px 0"
			sm-align-items="center"
			sm-justify-content="center"
			quarkly-title="Hero"
			background="#000000"
		>
			<Override
				slot="SectionContent"
				md-margin="0px 16px 0px 16px"
				width="100%"
				height="620px"
				justify-content="center"
				sm-width="100%"
				min-width="auto"
				margin="0px 32px 0px 32px"
				align-items="center"
				lg-height="520px"
				md-height="420px"
				md-padding="0px 24px 0px 24px"
				position="static"
			/>
			<Link
				text-decoration-line="initial"
				color="--light"
				padding="12px 24px 12px 24px"
				letter-spacing="0.5px"
				transition="transform 0.5s --transitionTimingFunction-easeInOut 0s"
				href="/index1"
				background="--color-green linear-gradient(0deg,#ffffff 0%,rgba(0,0,0,1) 100%)"
				font="normal 400 16px/1.5 --fontFamily-googleJosefinSans"
				hover-transform="translateY(-4px)"
				position="absolute"
				z-index="1"
				bottom="383px"
				height="24px"
				left="auto"
				right="578px"
				top="auto"
				width="63.638903515625px"
				hover-background="--color-green radial-gradient(circle at center,#ffffff 0%,rgba(0,0,0,1) 100%)"
				border-width="1px"
				border-radius="19px"
				border-color="#112357"
				hover-color="--dark"
				text-align="center"
				active-background="--color-green"
			>
				<Strong
					overflow-wrap="normal"
					word-break="normal"
					white-space="normal"
					text-indent="0"
					text-overflow="clip"
					hyphens="manual"
					user-select="auto"
					pointer-events="auto"
				>
					Enter
				</Strong>
			</Link>
			<Text
				font="normal 900 50px/1.2 --fontFamily-googleTitanOne"
				margin="16px 0px 0px 0px"
				sm-text-align="center"
				sm-width="80%"
				lg-text-align="center"
				lg-font="--headline2"
				color="--light"
				position="absolute"
				bottom="auto"
				height="84.57479306640624px"
				left="479.961px"
				right="444.1173095703125px"
				top="165px"
				width="355.9216904296875px"
				z-index="1"
				hover-color="--red"
				transition="all 0.5s ease-in-out 0s"
			>
				Enter The Jar
			</Text>
			<Text
				sm-text-align="center"
				sm-width="80%"
				opacity="1"
				md-text-align="center"
				font="normal 400 20px/1.5 --fontFamily-googleRighteous"
				color="--lightD2"
				margin="10px 0px 35px 0px"
				position="absolute"
				bottom="auto"
				height="112.51968383789062px"
				left="auto"
				right="554px"
				top="254px"
				width="164.62268945312502px"
				text-align="center"
				z-index="1"
				hover-color="--orange"
				transition="all 0.5s ease-in-out 0s"
			>
				3140 BrainyJars excited to join the Solana Ecosystem
			</Text>
			<Image
				src="https://uploads.quarkly.io/65c28f65009abe001f02fdd6/images/NFT-BRAIN-F_copy-removebg-preview.png?v=2024-02-06T20:06:36.102Z"
				display="block"
				bottom="71.0078px"
				height="700.3583787841796px"
				left="auto"
				position="absolute"
				right="242px"
				top="92.63362121582031px"
				width="770.7740375976563px"
				opacity=".25"
				z-index="0"
				srcSet="https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/NFT-BRAIN-F_copy-removebg-preview.png?v=2024-02-06T20%3A06%3A36.102Z&quality=85&w=500 500w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/NFT-BRAIN-F_copy-removebg-preview.png?v=2024-02-06T20%3A06%3A36.102Z&quality=85&w=800 800w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/NFT-BRAIN-F_copy-removebg-preview.png?v=2024-02-06T20%3A06%3A36.102Z&quality=85&w=1080 1080w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/NFT-BRAIN-F_copy-removebg-preview.png?v=2024-02-06T20%3A06%3A36.102Z&quality=85&w=1600 1600w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/NFT-BRAIN-F_copy-removebg-preview.png?v=2024-02-06T20%3A06%3A36.102Z&quality=85&w=2000 2000w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/NFT-BRAIN-F_copy-removebg-preview.png?v=2024-02-06T20%3A06%3A36.102Z&quality=85&w=2600 2600w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/NFT-BRAIN-F_copy-removebg-preview.png?v=2024-02-06T20%3A06%3A36.102Z&quality=85&w=3200 3200w"
				sizes="(max-width: 479px) 100vw,(max-width: 767px) 100vw,(max-width: 991px) 100vw,(max-width: 1199px) 100vw,100vw"
			/>
		</Section>
		<Section
			margin="0 0 0 0"
			padding="16px 0 16px 0"
			box-sizing="border-box"
			quarkly-title="Footer"
			justify-content="center"
		>
			<Override
				slot="SectionContent"
				width="100%"
				md-margin="0px 16px 0px 16px"
				min-width="auto"
				margin="0px 32px 0px 32px"
			/>
			<Box
				grid-gap="32px"
				width="100%"
				grid-template-columns="repeat(2, 1fr)"
				sm-grid-gap="16px"
				display="grid"
			>
				<Box display="flex" align-items="center" sm-flex-wrap="wrap">
					<Image width="28px" height="28px" src="https://uploads.quarkly.io/5f44d0da669357001e60ed14/images/default-website-quarkly-logo-grey.svg?v=2020-11-06T17:24:35.270Z" />
					<Link
						white-space="nowrap"
						font="--base"
						opacity="0.6"
						text-align="left"
						margin="1px 0px 0px 10px"
						href="https://quarkly.io/"
						color="--dark"
						text-decoration-line="initial"
						hover-text-decoration-line="underline"
					>
						Made on Quarkly
					</Link>
				</Box>
				<SocialMedia facebook="https://www.facebook.com/quarklyapp/" twitter="https://twitter.com/quarklyapp" youtube="https://www.youtube.com/channel/UCK5bXs2L0bbSMQ82BQ3hIkw" justify-content="flex-end">
					<Override slot="link" background="none" border-radius="50%" />
					<Override slot="icon" color="--dark" />
				</SocialMedia>
			</Box>
		</Section>
	</Theme>;
});