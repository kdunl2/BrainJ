import React from "react";
import theme from "theme";
import { Theme, Text, Button, Section, Link, Box, Image, Strong, Icon } from "@quarkly/widgets";
import { Helmet } from "react-helmet";
import { GlobalQuarklyPageStyles } from "global-page-styles";
import { Override, SocialMedia } from "@quarkly/components";
import * as Components from "components";
import { MdMenu, MdAttachMoney, MdAlarmOn } from "react-icons/md";
import { BsUnlock } from "react-icons/bs";
import { GiCalendar, GiShakingHands } from "react-icons/gi";
export default (() => {
	return <Theme theme={theme}>
		<GlobalQuarklyPageStyles pageUrl={"index1"} />
		<Helmet>
			<title>
				Home | Website Example
			</title>
			<meta name={"description"} content={"It all begins with an idea. Maybe you want to launch a business. Maybe you want to turn a hobby into something bigger. Or maybe you have a creative project to share with the world. Whatever it is, the way you tell your story online can make all the difference."} />
			<meta property={"og:title"} content={"Home | Website Example"} />
			<meta property={"og:description"} content={"It all begins with an idea. Maybe you want to launch a business. Maybe you want to turn a hobby into something bigger. Or maybe you have a creative project to share with the world. Whatever it is, the way you tell your story online can make all the difference."} />
			<meta property={"og:image"} content={"https://uploads.quarkly.io/5f44d0da669357001e60ed14/images/website-example-quarkly.png?v=2020-11-05T19:48:01.806Z"} />
			<link rel={"shortcut icon"} href={"https://uploads.quarkly.io/readme/cra/favicon-32x32.ico"} type={"image/x-icon"} />
		</Helmet>
		<Section
			padding="16px 0 16px 0"
			quarkly-title="Header"
			align-items="center"
			justify-content="center"
			background="#ff5906"
		>
			<Override
				slot="SectionContent"
				md-margin="0px 16px 0px 16px"
				display="grid"
				grid-template-columns="repeat(3, 1fr)"
				md-grid-template-columns="repeat(2, 1fr)"
				margin="0px 32px 0px 32px"
				width="100%"
			/>
			<Text margin="0px 0px 0px 0px" font="16px --fontFamily-googleMaterialSymbolsOutlined">
				BrainyYJars
			</Text>
			<Components.BurgerMenu md-display="flex" md-align-items="center" md-justify-content="flex-end">
				<Override slot="icon-open" md-position="fixed" md-top="18px" md-right="18px" />
				<Override
					slot="menu"
					md-top={0}
					md-width="100%"
					justify-content="center"
					lg-transition="transform 400ms ease 0s"
					md-position="fixed"
					display="flex"
					md-left={0}
					lg-transform="translateY(0px) translateX(0px)"
					md-height="100%"
					padding="0px 0 0px 0"
					align-items="center"
				>
					<Override
						slot="item"
						md-padding="16px 40px 16px 40px"
						display="inline-block"
						text-transform="uppercase"
						text-align="center"
						padding="8px 20px 8px 20px"
					/>
					<Override slot="item-404" lg-display="none" display="none" />
					<Override slot="item-index" lg-display="none" display="none" />
					<Override
						slot="link"
						md-hover-opacity="1"
						md-active-opacity="1"
						md-color="--dark"
						font="--base"
						text-transform="initial"
						md-font="16px/24px sans-serif"
						text-decoration-line="initial"
						color="--dark"
						transition="opacity .15s ease 0s"
						letter-spacing="0.5px"
						md-opacity=".5"
						md-transition="opacity .15s ease 0s"
						opacity=".5"
						hover-opacity="1"
					/>
					<Override
						slot="link-active"
						md-opacity="1"
						md-cursor="default"
						opacity="1"
						color="--primary"
						cursor="default"
					/>
				</Override>
				<Override slot="icon,icon-close" category="md" icon={MdMenu} />
				<Override
					slot="icon"
					category="md"
					icon={MdMenu}
					size="36px"
					md-right="0px"
					md-position="relative"
				/>
				<Override
					slot="menu-open"
					md-justify-content="center"
					md-top={0}
					md-bottom={0}
					md-display="flex"
					md-flex-direction="column"
					md-align-items="center"
				/>
			</Components.BurgerMenu>
			<Button
				md-display="none"
				white-space="nowrap"
				transition="transform --transitionDuration-fast --transitionTimingFunction-easeInOut 0s"
				font="--base"
				letter-spacing="0.5px"
				z-index="5"
				background="--color-primary"
				padding="8px 18px 8px 18px"
				border-radius="0px"
				hover-transform="translateY(-4px)"
				justify-self="end"
			>
				Contact Us
			</Button>
		</Section>
		<Components.Front />
		<Section
			box-sizing="border-box"
			lg-padding="50px 30px 50px 30px"
			id="mission"
			padding="90px 0px 100px 0px"
			quarkly-title="About"
			border-color="--color-lightD2"
			border-style="solid"
			border-width="1px 0px 1px 0px"
			sm-padding="24px 0 24px 0"
			justify-content="center"
			background="--color-grey"
		>
			<Override
				slot="SectionContent"
				md-margin="0px 16px 0px 16px"
				align-items="center"
				width="100%"
				min-width="auto"
				margin="0px 32px 0px 32px"
				color="#ffffff"
				border-color="#fff8f8"
			/>
			<Text
				text-align="center"
				font="normal 400 16px/1.5 --fontFamily-googleJosefinSans"
				opacity="0.6"
				letter-spacing="1px"
				margin="0px 0px 10px 0px"
				lg-margin="0px 0px 6px 0px"
				quarkly-title="Title"
				text-transform="uppercase"
				color="--light"
				lg-text-align="center"
			>
				Our Mission
			</Text>
			<Text
				letter-spacing="1px"
				color="--light"
				text-align="center"
				width="85%"
				lg-font="--lead"
				sm-font="--base"
				font="normal 300 28px/1.2 --fontFamily-googleJosefinSans"
				margin="0px 0px 0px 0px"
				border-color="#ffffff"
			>
				Our mission is to revolutionize the NFT landscape by merging education, collaboration, and innovation. We aim to empower individuals to explore the vast potential of NFTs, fostering a community where learning leads to earning. Through strategic partnerships and a unique reward system, we strive to make the digital art and collectibles market accessible, engaging, and rewarding for all. By democratizing knowledge and offering tangible rewards, we are committed to building a platform that not only serves as a gateway to the world of NFTs but also nurtures a culture of appreciation, understanding, and investment in digital creativity. Together, we are unlocking the future of NFTs, one discovery at a time.
			</Text>
		</Section>
		<Section
			md-padding="25px 0px 25px 0px"
			justify-content="center"
			padding="70px 0 70px 0"
			quarkly-title="Info"
			lg-padding="50px 0px 50px 0px"
			background="#ff5906"
		>
			<Override
				slot="SectionContent"
				width="100%"
				min-width="auto"
				margin="0px 32px 0px 32px"
				md-margin="0px 16px 0px 16px"
			/>
			<Box
				lg-grid-template-columns="1fr"
				display="grid"
				grid-template-columns="2fr 3fr"
				grid-gap="64px"
				xl-grid-gap="32px"
				md-grid-template-columns="1fr"
			>
				<Box
					min-width="100px"
					min-height="100px"
					display="flex"
					flex-direction="column"
					align-items="flex-start"
				>
					<Text
						font="--base"
						letter-spacing="1px"
						quarkly-title="Title"
						margin="0px 0px 10px 0px"
						color="--dark"
						opacity="0.6"
						lg-text-align="center"
						lg-margin="0px 0px 6px 0px"
						text-transform="uppercase"
					>
						Team
					</Text>
					<Text
						md-font="--headline3"
						font="normal 900 42px/1.2 --fontFamily-googleBebasNeue"
						margin="0px 0px 28px 0px"
						color="--dark"
						lg-text-align="center"
						lg-margin="0px 0px 18px 0px"
						sm-font="--headline3"
					>
						Who
					</Text>
					<Text
						lg-margin="0px 0px 18px 0px"
						sm-font="--base"
						font="--lead"
						margin="0px 0px 20px 0px"
						color="#000000"
						opacity="0.6"
						lg-text-align="left"
					>
						We are a collective of innovators dedicated to unlocking the potential of tomorrow's investors. Our mission leverages NFTs as keys to a world of knowledge, offering users the opportunity to deepen their understanding of cryptocurrencies, NFTsand beyond. By engaging with our platform, members not only gain invaluable insights but also earn cryptocurrency rewards. Embark with us on a path where knowledge and growth go hand-in-hand, transforming the way you build wealth.
					</Text>
					<Link
						href="/about"
						color="--light"
						padding="8px 18px 8px 18px"
						text-align="center"
						transition="transform --transitionDuration-fast --transitionTimingFunction-easeInOut 0s"
						text-decoration-line="initial"
						font="--base"
						letter-spacing="0.5px"
						margin="9px 0px 0px 0px"
						background="--color-primary"
						hover-transform="translateY(-4px)"
					>
						Read More
					</Link>
				</Box>
				<Box
					padding="0px 0px 60% 0px"
					height="0px"
					hover-background="--color-lightD2 url(https://uploads.quarkly.io/5f44d0da669357001e60ed14/images/default-website-illustration-sea-first.svg?v=2020-11-06T16:37:39.391Z) center center/110% no-repeat"
					transition="background --transitionDuration-normal --transitionTimingFunction-easeInOut 0s"
					md-order="-1"
					width="100%"
					margin="0px 0px 0px 0px"
					lg-order="-1"
					background="#ff5906 url(https://uploads.quarkly.io/65c28f65009abe001f02fdd6/images/ninth.png?v=2024-02-06T21:56:51.809Z) 50% 50% /contain repeat-y scroll padding-box"
					position="static"
				/>
			</Box>
			<Box
				md-margin="44px 0px 0px 0px"
				lg-grid-template-columns="1fr"
				display="grid"
				grid-template-columns="3fr 2fr"
				grid-gap="64px"
				margin="96px 0px 0px 0px"
				xl-grid-gap="32px"
				md-grid-template-columns="1fr"
				lg-margin="64px 0px 0px 0px"
			>
				<Image
					src="https://uploads.quarkly.io/65c28f65009abe001f02fdd6/images/third.png?v=2024-02-06T21:56:51.808Z"
					display="block"
					width="500px"
					srcSet="https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/third.png?v=2024-02-06T21%3A56%3A51.808Z&quality=85&w=500 500w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/third.png?v=2024-02-06T21%3A56%3A51.808Z&quality=85&w=800 800w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/third.png?v=2024-02-06T21%3A56%3A51.808Z&quality=85&w=1080 1080w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/third.png?v=2024-02-06T21%3A56%3A51.808Z&quality=85&w=1600 1600w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/third.png?v=2024-02-06T21%3A56%3A51.808Z&quality=85&w=2000 2000w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/third.png?v=2024-02-06T21%3A56%3A51.808Z&quality=85&w=2600 2600w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/third.png?v=2024-02-06T21%3A56%3A51.808Z&quality=85&w=3200 3200w"
					sizes="(max-width: 479px) 100vw,(max-width: 767px) 100vw,(max-width: 991px) 100vw,(max-width: 1199px) 100vw,100vw"
				/>
				<Box
					display="flex"
					flex-direction="column"
					align-items="flex-start"
					min-width="100px"
					min-height="100px"
				>
					<Text
						lg-text-align="center"
						quarkly-title="Title"
						text-transform="uppercase"
						opacity="0.6"
						lg-margin="0px 0px 6px 0px"
						font="--base"
						margin="0px 0px 10px 0px"
						letter-spacing="1px"
						color="--dark"
					>
						Vision
					</Text>
					<Text
						font="normal 900 42px/1.2 --fontFamily-googleBebasNeue"
						margin="0px 0px 28px 0px"
						color="--dark"
						lg-text-align="center"
						lg-margin="0px 0px 18px 0px"
						sm-font="--headline3"
						md-font="--headline3"
					>
						Why
					</Text>
					<Text
						opacity="0.6"
						sm-text-align="left"
						lg-text-align="left"
						lg-margin="0px 0px 18px 0px"
						sm-font="--base"
						font="--lead"
						margin="0px 0px 20px 0px"
						color="--darkL2"
					>
						We created this platform because we believe knowledge is key to navigating the digital economy's opportunities. Our aim is to bridge the gap between the vast potential of blockchain technology and the public's access to empowering information. By integrating education with rewards, we strive to make learning about cryptocurrencies, NFTs, and digital assets both accessible and rewarding. Our project is driven by the desire to foster a community where informed decision-making and innovation lead to growth and wealth, democratizing the future of finance and technology for all.
					</Text>
					<Link
						color="--light"
						text-align="center"
						background="--color-primary"
						transition="transform --transitionDuration-fast --transitionTimingFunction-easeInOut 0s"
						hover-transform="translateY(-4px)"
						href="/team"
						text-decoration-line="initial"
						padding="8px 18px 8px 18px"
						font="--base"
						letter-spacing="0.5px"
						margin="9px 0px 0px 0px"
					>
						Read More
					</Link>
				</Box>
			</Box>
			<Box
				md-margin="44px 0px 0px 0px"
				lg-grid-template-columns="1fr"
				display="grid"
				grid-template-columns="2fr 3fr"
				xl-grid-gap="32px"
				md-grid-template-columns="1fr"
				lg-margin="64px 0px 0px 0px"
				grid-gap="64px"
				margin="96px 0px 0px 0px"
			>
				<Box
					min-width="100px"
					min-height="100px"
					display="flex"
					flex-direction="column"
					align-items="flex-start"
				>
					<Text
						quarkly-title="Title"
						text-transform="uppercase"
						lg-text-align="center"
						margin="0px 0px 10px 0px"
						letter-spacing="1px"
						color="--dark"
						opacity="0.6"
						lg-margin="0px 0px 6px 0px"
						font="--base"
					>
						NFTS
					</Text>
					<Text
						font="--headline2"
						margin="0px 0px 28px 0px"
						color="--dark"
						lg-text-align="center"
						lg-margin="0px 0px 18px 0px"
						sm-text-align="left"
						sm-font="--headline3"
						md-font="--headline3"
					>
						What
					</Text>
					<Text
						font="--lead"
						margin="0px 0px 20px 0px"
						color="--darkL2"
						opacity="0.6"
						lg-text-align="left"
						lg-margin="0px 0px 18px 0px"
						sm-font="--base"
					>
						BrainyJar NFTs' represent an exclusive collection launching on the Solana blockchain, designed to serve as your gateway to our innovative platform. Each NFT acts as a unique key, unlocking access to a comprehensive learning ecosystem focused on cryptocurrencies, NFTs and much more. Beyond mere access, holders of these NFTs are also eligible for cryptocurrency rewards. This dual function not only enhances the value of holding a BrainyJar NFT but also aligns with our mission to intertwine knowledge acquisition with tangible financial benefits. By owning a BrainyJar NFT, you're not just part of a community; you're holding a piece of the future where education meets opportunity on the blockchain.
					</Text>
					<Link
						margin="9px 0px 0px 0px"
						hover-transform="translateY(-4px)"
						text-decoration-line="initial"
						padding="8px 18px 8px 18px"
						font="--base"
						transition="transform --transitionDuration-fast --transitionTimingFunction-easeInOut 0s"
						text-align="center"
						href="/contact"
						color="--light"
						letter-spacing="0.5px"
						background="--color-primary"
					>
						Read More
					</Link>
				</Box>
				<Image
					src="https://uploads.quarkly.io/65c28f65009abe001f02fdd6/images/fourth.png?v=2024-02-06T21:56:51.825Z"
					display="block"
					width="600px"
					srcSet="https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/fourth.png?v=2024-02-06T21%3A56%3A51.825Z&quality=85&w=500 500w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/fourth.png?v=2024-02-06T21%3A56%3A51.825Z&quality=85&w=800 800w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/fourth.png?v=2024-02-06T21%3A56%3A51.825Z&quality=85&w=1080 1080w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/fourth.png?v=2024-02-06T21%3A56%3A51.825Z&quality=85&w=1600 1600w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/fourth.png?v=2024-02-06T21%3A56%3A51.825Z&quality=85&w=2000 2000w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/fourth.png?v=2024-02-06T21%3A56%3A51.825Z&quality=85&w=2600 2600w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/fourth.png?v=2024-02-06T21%3A56%3A51.825Z&quality=85&w=3200 3200w"
					sizes="(max-width: 479px) 100vw,(max-width: 767px) 100vw,(max-width: 991px) 100vw,(max-width: 1199px) 100vw,100vw"
				/>
			</Box>
		</Section>
		<Section
			padding="40px 0 40px 0"
			quarkly-title="Description-11"
			color="#ffffff"
			height="1001px"
			background="--color-grey"
		>
			<Override
				slot="SectionContent"
				flex-wrap="wrap"
				max-width="1440px"
				align-items="flex-start"
				flex-direction="row"
			/>
			<Box border-color="--color-light" width="100%" border-width="0px 0px 1px 0px" border-style="solid">
				<Text margin="0px 0px 2vh 0px" color="--light" font="normal 400 20px/1.5 --fontFamily-googleOswald">
					Why should YOU get a BrainyJars NFT?
				</Text>
			</Box>
			<Box
				width="441.00048974609376px"
				padding="20px 20px 20px 20px"
				margin="156px 0px 100px 0px"
				lg-margin="56px 0px 30px 0px"
				md-width="50%"
				sm-margin="20px 0px 20px 0px"
				sm-width="100%"
				position="absolute"
				bottom="auto"
				height="251.188px"
				left="auto"
				right="auto"
				top="auto"
				border-color="#c81515"
			>
				<Text margin="0px 0px 0px 0px" font="--headline3" color="--light">
					<Strong
						overflow-wrap="normal"
						word-break="normal"
						white-space="normal"
						text-indent="0"
						text-overflow="clip"
						hyphens="manual"
						user-select="auto"
						pointer-events="auto"
					>
						Exclusive Access to Premium Content
					</Strong>
				</Text>
				<Icon
					category="bs"
					icon={BsUnlock}
					size="64px"
					position="absolute"
					bottom="auto"
					height="64px"
					left="165px"
					right="auto"
					top="-62px"
					width="64px"
				/>
				<Text margin="40px 0px 0px 0px" font="--base" color="--light">
					Owning a BrainyJar NFT unlocks exclusive access to a curated platform of educational materials. This includes in-depth courses, webinars, and articles on cryptocurrencies, NFTs and more, designed to expand your knowledge and skills in the digital economy.
				</Text>
			</Box>
			<Box
				sm-width="100%"
				width="33.333%"
				padding="20px 20px 20px 20px"
				margin="156px 0px 100px 0px"
				lg-margin="56px 0px 30px 0px"
				md-width="50%"
				sm-margin="20px 0px 20px 0px"
				position="absolute"
				bottom="2202px"
				height="145.594px"
				left="auto"
				right="235px"
				top="auto"
			>
				<Icon
					category="md"
					icon={MdAttachMoney}
					size="64px"
					align-items="flex-end"
					align-content="flex-end"
					position="absolute"
					bottom="auto"
					height="64px"
					left="173px"
					right="auto"
					top="-67px"
					width="64px"
				/>
				<Text margin="0px 0px 0px 0px" font="--headline3" color="--light">
					<Strong>
						Crypto Rewards for Engagement
					</Strong>
				</Text>
				<Text margin="40px 0px 0px 0px" font="--base" color="--light">
					Holders are rewarded with cryptocurrency for actively engaging with the platform’s educational content, offering a unique opportunity to earn while you learn.
				</Text>
			</Box>
			<Box
				md-width="50%"
				sm-margin="20px 0px 20px 0px"
				sm-width="100%"
				width="33.333%"
				padding="20px 20px 20px 20px"
				margin="156px 0px 100px 0px"
				lg-margin="56px 0px 30px 0px"
				position="absolute"
				bottom="1719px"
				height="40px"
				left="62px"
				right="auto"
				top="auto"
			>
				<Text margin="0px 0px 0px 0px" font="--headline3" color="--light" text-align="center">
					<Strong
						overflow-wrap="normal"
						word-break="normal"
						white-space="normal"
						text-indent="0"
						text-overflow="clip"
						hyphens="manual"
						user-select="auto"
						pointer-events="auto"
					>
						And much more to come...
					</Strong>
				</Text>
				<Text font="--base" color="--light" margin="40px 0px 0px 0px" />
			</Box>
			<Box
				md-width="50%"
				sm-margin="20px 0px 20px 0px"
				sm-width="100%"
				width="33.333%"
				padding="20px 20px 20px 20px"
				margin="156px 0px 100px 0px"
				lg-margin="56px 0px 30px 0px"
				position="absolute"
				top="auto"
				right="auto"
				bottom="1989px"
				left="68px"
				height="169.594px"
			>
				<Icon
					category="gi"
					icon={GiCalendar}
					size="64px"
					position="absolute"
					bottom="auto"
					height="64px"
					left="194px"
					right="auto"
					top="-60px"
					width="64px"
				/>
				<Text margin="0px 0px 0px 0px" font="--headline3" color="--light" text-align="center">
					<Strong>
						Consolidated Platform for Upcoming Projects
					</Strong>
				</Text>
				<Text font="--base" color="--light" margin="40px 0px 0px 0px">
					Access a centralized hub for discovering and learning about upcoming blockchain projects, allowing you to get in early and seize opportunities before they become mainstream.
				</Text>
			</Box>
			<Box
				md-width="50%"
				sm-margin="20px 0px 20px 0px"
				sm-width="100%"
				width="448.80339843750005px"
				padding="20px 20px 20px 20px"
				margin="156px 0px 100px 0px"
				lg-margin="56px 0px 30px 0px"
				position="absolute"
				bottom="1776px"
				height="203.188px"
				left="auto"
				right="206px"
				top="auto"
			>
				<Icon
					category="md"
					icon={MdAlarmOn}
					size="64px"
					position="absolute"
					bottom="auto"
					height="64px"
					left="194px"
					right="auto"
					top="-59px"
					width="64px"
				/>
				<Text color="--light" margin="0px 0px 0px 0px" font="--headline3">
					<Strong>
						Early Access and Whitelist Spots for New Projects
					</Strong>
					:{" "}
				</Text>
				<Text margin="40px 0px 0px 0px" font="--base" color="--light">
					Enjoy early access to new features and exclusive projects launched on the platform, along with guaranteed whitelist spots for future NFT drops, ensuring you’re always ahead in the evolving world of digital assets.
				</Text>
			</Box>
			<Box
				md-width="50%"
				sm-margin="20px 0px 20px 0px"
				sm-width="100%"
				width="33.333%"
				padding="20px 20px 20px 20px"
				margin="156px 0px 100px 0px"
				lg-margin="56px 0px 30px 0px"
				position="absolute"
				top="auto"
				right="108px"
				bottom="2879px"
				left="auto"
				height="169.594px"
			>
				<Icon
					category="gi"
					icon={GiShakingHands}
					size="64px"
					position="absolute"
					bottom="auto"
					height="64px"
					left="160px"
					right="auto"
					top="-56px"
					width="64px"
				/>
				<Text margin="0px 0px 0px 0px" font="--headline3" color="--light">
					<Strong>
						Community Membership
					</Strong>
				</Text>
				<Text font="--base" color="--light" margin="40px 0px 0px 0px">
					{" "}Becoming a BrainyJar NFT holder grants you membership to a vibrant community of individuals passionate about blockchain and personal growth, fostering networking and collaborative learning opportunities.
				</Text>
			</Box>
		</Section>
		<Section
			padding="120px 0 130px 0"
			lg-padding="80px 0 90px 0"
			quarkly-title="Stages/Steps-5"
			height="1000px"
			color="#ff5906"
			background="#ff5906"
		>
			<Text
				margin="0px 0px 90px 0px"
				font="normal 600 42px/1.2 --fontFamily-googleShadowsIntoLight"
				color="--light"
				border-color="--color-dark"
				text-align="center"
				lg-margin="0px 0px 50px 0px"
			>
				Roadmap
			</Text>
			<Image
				src="https://uploads.quarkly.io/65c28f65009abe001f02fdd6/images/NFT-BRAIN-F_copy-removebg-preview.png?v=2024-02-06T20:06:36.102Z"
				display="block"
				position="absolute"
				bottom="604.4302978515625px"
				height="1159.3397021484375px"
				left="auto"
				right="-43px"
				top="4462.23px"
				width="1314.2854840087891px"
				z-index="0"
				opacity=".1"
				srcSet="https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/NFT-BRAIN-F_copy-removebg-preview.png?v=2024-02-06T20%3A06%3A36.102Z&quality=85&w=500 500w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/NFT-BRAIN-F_copy-removebg-preview.png?v=2024-02-06T20%3A06%3A36.102Z&quality=85&w=800 800w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/NFT-BRAIN-F_copy-removebg-preview.png?v=2024-02-06T20%3A06%3A36.102Z&quality=85&w=1080 1080w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/NFT-BRAIN-F_copy-removebg-preview.png?v=2024-02-06T20%3A06%3A36.102Z&quality=85&w=1600 1600w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/NFT-BRAIN-F_copy-removebg-preview.png?v=2024-02-06T20%3A06%3A36.102Z&quality=85&w=2000 2000w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/NFT-BRAIN-F_copy-removebg-preview.png?v=2024-02-06T20%3A06%3A36.102Z&quality=85&w=2600 2600w,https://smartuploads.quarkly.io/65c28f65009abe001f02fdd6/images/NFT-BRAIN-F_copy-removebg-preview.png?v=2024-02-06T20%3A06%3A36.102Z&quality=85&w=3200 3200w"
				sizes="(max-width: 479px) 100vw,(max-width: 767px) 100vw,(max-width: 991px) 100vw,(max-width: 1199px) 100vw,100vw"
			/>
			<Box
				min-width="100px"
				min-height="100px"
				display="flex"
				grid-template-columns="repeat(3, 1fr)"
				md-grid-template-columns="1fr"
				md-grid-template-rows="auto"
				md-grid-gap={0}
				lg-padding="0px 0 0px 0"
				flex-direction="column"
				align-self="center"
				position="static"
			>
				<Box
					min-width="100px"
					min-height="100px"
					display="flex"
					flex-direction="row"
					padding="0px 50px 0 0"
					lg-padding="0px 25px 0 0"
					position="relative"
				>
					<Box
						min-width="40px"
						min-height="40px"
						background="--color-darkL1"
						display="flex"
						width="40px"
						height="40px"
						border-radius="50%"
						margin="0px 0px 30px 0px"
						color="--darkL2"
						align-items="center"
						justify-content="center"
						position="relative"
						z-index="3"
					>
						<Text margin="0px 0px 0px 0px" color="--light" font="--lead" text-align="center">
							1
						</Text>
					</Box>
					<Box
						min-width="100px"
						min-height="100px"
						margin="0px 0px 0px -20px"
						border-width="0 0 0 1px"
						border-style="solid"
						border-color="#c8ced7"
						padding="0px 0px 0px 20px"
					>
						<Text
							margin="0 0 15px 25px"
							border-color="--color-light"
							color="--light"
							font="normal 500 28px/1.2 --fontFamily-googleShadowsIntoLight"
							text-align="left"
						>
							Phase One: Launch and Establishment
						</Text>
						<Text
							margin="0 0 0 25px"
							font="normal 400 16px/1.5 --fontFamily-sansHelvetica"
							color="--light"
							text-align="left"
							border-color="#7a7c7f"
							padding="0px 0px 50px 0px"
						>
							Official launch of the 3140 BrainyJar NFT collection on the Solana blockchain.
							<br />
							Collaborations with new and current projects to receive content and whitelist spots.
							<br />
							Release of the initial set of premium educational content accessible exclusively by NFT holders.
						</Text>
					</Box>
				</Box>
				<Box
					min-width="100px"
					min-height="100px"
					display="flex"
					flex-direction="row"
					padding="0px 50px 0 0"
					lg-padding="0px 25px 0 0"
					position="relative"
				>
					<Box
						min-width="40px"
						min-height="40px"
						background="--color-darkL1"
						display="flex"
						align-items="center"
						justify-content="center"
						width="40px"
						height="40px"
						border-radius="50%"
						margin="0px 0px 30px 0px"
						color="--darkL2"
						position="relative"
						z-index="3"
					>
						<Text margin="0px 0px 0px 0px" color="--light" font="--lead" text-align="center">
							2
						</Text>
					</Box>
					<Box
						min-width="100px"
						min-height="100px"
						margin="0px 0px 0px -20px"
						padding="0px 0px 0px 20px"
						border-color="#c8ced7"
						border-style="solid"
						border-width="0 0 0 1px"
					>
						<Text
							margin="0 0 15px 25px"
							border-color="--color-light"
							color="--light"
							font="normal 500 29px/1.2 --fontFamily-googleShadowsIntoLight"
							text-align="left"
						>
							Phase 2: Community Growth and Engagement
						</Text>
						<Text
							margin="0 0 0 25px"
							font="normal 400 16px/1.5 --fontFamily-sansHelvetica"
							color="--light"
							text-align="left"
							border-color="#7a7c7f"
							padding="0px 0px 50px 0px"
						>
							Continue to grow the community and collaborations.
							<br />
							Raffles and Airdrops.
							<br />
							{" "}Launch of a referral program to incentivize community growth and engagement.
							<br />
							Initial Airdrop to all holders from secondary market royalty treasury.
							<br />
							Maintain treasury to use as crypto rewards in platform
						</Text>
					</Box>
				</Box>
				<Box
					min-width="100px"
					min-height="100px"
					display="flex"
					flex-direction="row"
					padding="0px 50px 30px 0"
					sm-padding="0px 0 0 0"
					lg-padding="0px 25px 0 0"
					md-margin="0px 0px 30px 0px"
					sm-margin="0px 0px 20px 0px"
					position="absolute"
					bottom="713px"
					height="100px"
					left="auto"
					right="500px"
					top="auto"
					width="100px"
				>
					<Box
						min-width="40px"
						min-height="40px"
						background="--color-darkL1"
						display="flex"
						align-items="center"
						justify-content="center"
						width="40px"
						height="40px"
						border-radius="50%"
						margin="0px 0px 30px 0px"
						color="--darkL2"
						position="absolute"
						z-index="1"
						bottom="auto"
						left="-354px"
						right="auto"
						top="-51px"
					>
						<Text margin="0px 0px 0px 0px" color="--light" font="--lead" text-align="center">
							4
						</Text>
					</Box>
					<Box
						min-width="100px"
						min-height="100px"
						margin="0px 0px 0px 0"
						border-width="0 0 0 1px"
						border-style="solid"
						border-color="#c8ced7"
						position="absolute"
						top="-48px"
						right="auto"
						bottom="auto"
						left="-337px"
						width="660.812px"
						height="195.80180859375px"
						z-index="0"
					>
						<Text
							margin="0 0 15px 45px"
							border-color="--color-light"
							color="--light"
							font="normal 500 29px/1.2 --fontFamily-googleShadowsIntoLight"
							text-align="left"
						>
							Phase 4: Innovation and Future Projects
						</Text>
						<Text
							margin="0 0 0 45px"
							font="normal 400 16px/1.5 --fontFamily-sansHelvetica"
							color="--light"
							text-align="left"
							border-color="#7a7c7f"
						>
							Official launch of BrainyJars Second Collection.
							<br />
							Introduction of new blockchain technologies and concepts into the curriculum, keeping content at the cutting edge.
							<br />
							Exploration of AR/VR for immersive learning experiences.
							<br />
							Incorporation of collaborating projects providing crypto as rewards
						</Text>
					</Box>
				</Box>
				<Box
					min-width="100px"
					min-height="100px"
					display="flex"
					flex-direction="row"
					padding="0px 50px 30px 0"
					sm-padding="0px 0 0 0"
					lg-padding="0px 25px 0 0"
					md-margin="0px 0px 30px 0px"
					sm-margin="0px 0px 20px 0px"
				>
					<Box
						min-width="40px"
						min-height="40px"
						background="--color-darkL1"
						display="flex"
						align-items="center"
						justify-content="center"
						width="40px"
						height="40px"
						border-radius="50%"
						margin="0px 0px 30px 0px"
						color="--darkL2"
						position="relative"
						z-index="1"
					>
						<Text margin="0px 0px 0px 0px" color="--light" font="--lead" text-align="center">
							3
						</Text>
					</Box>
					<Box
						min-width="100px"
						min-height="100px"
						margin="0px 0px 0px 0"
						border-width="0 0 0 1px"
						border-style="solid"
						border-color="#c8ced7"
						position="absolute"
						top="auto"
						right="auto"
						bottom="886px"
						left="293px"
						width="660.812px"
						height="252.113826171875px"
						z-index="0"
					>
						<Text
							margin="0 0 15px 45px"
							border-color="--color-light"
							color="--light"
							font="normal 500 29px/1.2 --fontFamily-googleShadowsIntoLight"
							text-align="left"
						>
							Phase 3: Platform Expansion and New Features
						</Text>
						<Text
							margin="0 0 0 45px"
							font="normal 400 16px/1.5 --fontFamily-sansHelvetica"
							color="--light"
							text-align="left"
							border-color="#7a7c7f"
						>
							Expansion of educational content to cover more topics based on community feedback.
							<br />
							Expansion of platform to allow limited access to users who do not currently hold a BrainyJar NFT.
							<br />
							Introduction of gamification elements (badges, leaderboards) to enhance learning and engagement.
							<br />
							Early access and whitelist spots for new projects and exclusive NFT drops for BrainyJar holders.
						</Text>
					</Box>
				</Box>
			</Box>
		</Section>
		<Section
			sm-padding="24px 0 24px 0"
			background="--color-lightD1"
			border-style="solid"
			box-sizing="border-box"
			justify-content="center"
			padding="90px 0px 100px 0px"
			border-color="--color-lightD2"
			border-width="1px 0px 1px 0px"
			lg-padding="50px 30px 50px 30px"
			quarkly-title="FAQ"
		>
			<Override
				slot="SectionContent"
				width="100%"
				min-width="auto"
				margin="0px 48px 0px 48px"
				md-margin="0px 16px 0px 16px"
				align-items="center"
			/>
			<Text
				font="--base"
				margin="0px 0px 10px 0px"
				text-transform="uppercase"
				lg-margin="0px 0px 6px 0px"
				quarkly-title="Title"
				letter-spacing="1px"
				color="--dark"
				opacity="0.6"
				text-align="center"
				lg-text-align="center"
			>
				We're here to help
			</Text>
			<Text
				sm-font="--headline3"
				md-font="--headline3"
				font="--headline2"
				margin="0px 0px 64px 0px"
				color="--dark"
				text-align="center"
				lg-text-align="center"
				lg-margin="0px 0px 36px 0px"
			>
				FAQ
			</Text>
			<Box
				width="100%"
				display="grid"
				grid-gap="32px"
				grid-template-columns="repeat(4, 1fr)"
				lg-grid-template-columns="repeat(2, 1fr)"
				md-grid-template-columns="1fr"
			>
				<Box>
					<Text
						text-align="center"
						md-text-align="left"
						font="--lead"
						margin="0px 0px 0px 0px"
						color="--dark"
					>
						Have any questions?
					</Text>
					<Text
						text-align="center"
						margin="16px 0px 0px 0px"
						md-text-align="left"
						sm-margin="8px 0px 0px 0px"
						font="--base"
						color="--darkL2"
						opacity="0.6"
						lg-text-align="center"
					>
						It all begins with an idea. Maybe you want to launch a business. Maybe you want to turn a hobby into something bigger.
					</Text>
				</Box>
				<Box>
					<Text
						margin="0px 0px 0px 0px"
						color="--dark"
						text-align="center"
						md-text-align="left"
						font="--lead"
					>
						Have any questions?
					</Text>
					<Text
						lg-text-align="center"
						text-align="center"
						margin="16px 0px 0px 0px"
						md-text-align="left"
						sm-margin="8px 0px 0px 0px"
						font="--base"
						color="--darkL2"
						opacity="0.6"
					>
						It all begins with an idea. Maybe you want to launch a business. Maybe you want to turn a hobby into something bigger.
					</Text>
				</Box>
				<Box>
					<Text
						color="--dark"
						text-align="center"
						md-text-align="left"
						font="--lead"
						margin="0px 0px 0px 0px"
					>
						Have any questions?
					</Text>
					<Text
						font="--base"
						color="--darkL2"
						opacity="0.6"
						lg-text-align="center"
						text-align="center"
						margin="16px 0px 0px 0px"
						md-text-align="left"
						sm-margin="8px 0px 0px 0px"
					>
						It all begins with an idea. Maybe you want to launch a business. Maybe you want to turn a hobby into something bigger.
					</Text>
				</Box>
				<Box>
					<Text
						font="--lead"
						margin="0px 0px 0px 0px"
						color="--dark"
						text-align="center"
						md-text-align="left"
					>
						Have any questions?
					</Text>
					<Text
						lg-text-align="center"
						text-align="center"
						margin="16px 0px 0px 0px"
						md-text-align="left"
						sm-margin="8px 0px 0px 0px"
						font="--base"
						color="--darkL2"
						opacity="0.6"
					>
						It all begins with an idea. Maybe you want to launch a business. Maybe you want to turn a hobby into something bigger.
					</Text>
				</Box>
			</Box>
		</Section>
		<Section
			margin="0 0 0 0"
			padding="16px 0 16px 0"
			box-sizing="border-box"
			quarkly-title="Footer"
			justify-content="center"
		>
			<Override
				slot="SectionContent"
				width="100%"
				md-margin="0px 16px 0px 16px"
				min-width="auto"
				margin="0px 32px 0px 32px"
			/>
			<Box
				grid-gap="32px"
				width="100%"
				grid-template-columns="repeat(2, 1fr)"
				sm-grid-gap="16px"
				display="grid"
			>
				<SocialMedia facebook="https://www.facebook.com/quarklyapp/" twitter="https://twitter.com/quarklyapp" youtube="https://www.youtube.com/channel/UCK5bXs2L0bbSMQ82BQ3hIkw" justify-content="flex-end">
					<Override slot="link" background="none" border-radius="50%" />
					<Override slot="icon" color="--dark" />
				</SocialMedia>
			</Box>
		</Section>
	</Theme>;
});