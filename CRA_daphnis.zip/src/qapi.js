export default {
	"pages": {
		"root": {
			"name": "root",
			"children": [
				"65c28f65009abe001f02fdef",
				"65c28f65009abe001f02fdf3",
				"65c28f65009abe001f02fdf7",
				"65c28f65009abe001f02fdff",
				"65c28f65009abe001f02fdfb",
				"65c28f65009abe001f02fe03",
				"65c29004926d910020ec6313",
				"65c2c25e1d712a00232fb3d5"
			],
			"id": "root",
			"pageUrl": "root"
		},
		"65c28f65009abe001f02fdef": {
			"id": "65c28f65009abe001f02fdef",
			"name": "404",
			"pageUrl": "404"
		},
		"65c28f65009abe001f02fdf3": {
			"id": "65c28f65009abe001f02fdf3",
			"name": "index",
			"pageUrl": "index",
			"seo": {
				"og:description": "It all begins with an idea. Maybe you want to launch a business. Maybe you want to turn a hobby into something bigger. Or maybe you have a creative project to share with the world. Whatever it is, the way you tell your story online can make all the difference.",
				"title": "Home | Website Example",
				"og:title": "Home | Website Example",
				"og:image": "https://uploads.quarkly.io/5f44d0da669357001e60ed14/images/website-example-quarkly.png?v=2020-11-05T19:48:01.806Z",
				"description": "It all begins with an idea. Maybe you want to launch a business. Maybe you want to turn a hobby into something bigger. Or maybe you have a creative project to share with the world. Whatever it is, the way you tell your story online can make all the difference."
			}
		},
		"65c28f65009abe001f02fdf7": {
			"id": "65c28f65009abe001f02fdf7",
			"pageUrl": "about",
			"name": "About",
			"seo": {
				"og:title": "About | Website Example",
				"og:description": "It all begins with an idea. Maybe you want to launch a business. Maybe you want to turn a hobby into something bigger. Or maybe you have a creative project to share with the world. Whatever it is, the way you tell your story online can make all the difference.",
				"description": "It all begins with an idea. Maybe you want to launch a business. Maybe you want to turn a hobby into something bigger. Or maybe you have a creative project to share with the world. Whatever it is, the way you tell your story online can make all the difference.",
				"og:image": "https://uploads.quarkly.io/5f44d0da669357001e60ed14/images/website-example-quarkly.png?v=2020-11-05T19:48:01.806Z",
				"title": "About | Website Example"
			}
		},
		"65c28f65009abe001f02fdfb": {
			"id": "65c28f65009abe001f02fdfb",
			"seo": {
				"og:image": "https://uploads.quarkly.io/5f44d0da669357001e60ed14/images/website-example-quarkly.png?v=2020-11-05T19:48:01.806Z",
				"title": "Work | Website Example",
				"og:title": "Work | Website Example",
				"description": "It all begins with an idea. Maybe you want to launch a business. Maybe you want to turn a hobby into something bigger. Or maybe you have a creative project to share with the world. Whatever it is, the way you tell your story online can make all the difference.",
				"og:description": "It all begins with an idea. Maybe you want to launch a business. Maybe you want to turn a hobby into something bigger. Or maybe you have a creative project to share with the world. Whatever it is, the way you tell your story online can make all the difference."
			},
			"pageUrl": "work",
			"name": "Work"
		},
		"65c28f65009abe001f02fdff": {
			"id": "65c28f65009abe001f02fdff",
			"seo": {
				"description": "It all begins with an idea. Maybe you want to launch a business. Maybe you want to turn a hobby into something bigger. Or maybe you have a creative project to share with the world. Whatever it is, the way you tell your story online can make all the difference.",
				"og:description": "It all begins with an idea. Maybe you want to launch a business. Maybe you want to turn a hobby into something bigger. Or maybe you have a creative project to share with the world. Whatever it is, the way you tell your story online can make all the difference.",
				"og:image": "https://uploads.quarkly.io/5f44d0da669357001e60ed14/images/website-example-quarkly.png?v=2020-11-05T19:48:01.806Z",
				"title": "Team | Website Example",
				"og:title": "Team | Website Example"
			},
			"pageUrl": "team",
			"name": "Team"
		},
		"65c28f65009abe001f02fe03": {
			"id": "65c28f65009abe001f02fe03",
			"pageUrl": "contact",
			"name": "Contact",
			"seo": {
				"og:image": "https://uploads.quarkly.io/5f44d0da669357001e60ed14/images/website-example-quarkly.png?v=2020-11-05T19:48:01.806Z",
				"title": "Contact | Website Example",
				"og:title": "Contact | Website Example",
				"description": "It all begins with an idea. Maybe you want to launch a business. Maybe you want to turn a hobby into something bigger. Or maybe you have a creative project to share with the world. Whatever it is, the way you tell your story online can make all the difference.",
				"og:description": "It all begins with an idea. Maybe you want to launch a business. Maybe you want to turn a hobby into something bigger. Or maybe you have a creative project to share with the world. Whatever it is, the way you tell your story online can make all the difference."
			}
		},
		"65c29004926d910020ec6313": {
			"pageUrl": "index1",
			"seo": {
				"og:description": "It all begins with an idea. Maybe you want to launch a business. Maybe you want to turn a hobby into something bigger. Or maybe you have a creative project to share with the world. Whatever it is, the way you tell your story online can make all the difference.",
				"title": "Home | Website Example",
				"og:title": "Home | Website Example",
				"og:image": "https://uploads.quarkly.io/5f44d0da669357001e60ed14/images/website-example-quarkly.png?v=2020-11-05T19:48:01.806Z",
				"description": "It all begins with an idea. Maybe you want to launch a business. Maybe you want to turn a hobby into something bigger. Or maybe you have a creative project to share with the world. Whatever it is, the way you tell your story online can make all the difference."
			},
			"id": "65c29004926d910020ec6313",
			"name": "index"
		},
		"65c2c25e1d712a00232fb3d5": {
			"id": "65c2c25e1d712a00232fb3d5",
			"pageUrl": "main",
			"name": "main"
		}
	},
	"mode": "production",
	"projectType": "create-react-app",
	"site": {
		"styles": {},
		"seo": {}
	}
}