import React from "react";
import { useOverrides, Override } from "@quarkly/components";
import { Text, Image, Link, Section } from "@quarkly/widgets";
const defaultProps = {
	"lg-padding": "25px 0 25px 0",
	"sm-padding": "0px 0 25px 0",
	"justify-content": "center",
	"padding": "25px 0 75px 0",
	"sm-align-items": "center",
	"sm-justify-content": "center",
	"quarkly-title": "Hero",
	"background": "#ff5906"
};
const overrides = {
	"text": {
		"kind": "Text",
		"props": {
			"margin": "0px 0px 0px 0px",
			"font": "72px --fontFamily-googleMaterialSymbolsOutlined",
			"border-color": "--color-light",
			"position": "absolute",
			"top": "238.69952392578125px",
			"right": "107.63818359375px",
			"bottom": "5008px",
			"left": "654px",
			"width": "518.36181640625px",
			"height": "91.30047607421875px",
			"opacity": "0.5",
			"children": "BrainyYJars"
		}
	},
	"image": {
		"kind": "Image",
		"props": {
			"src": "https://uploads.quarkly.io/65c28f65009abe001f02fdd6/images/second.png?v=2024-02-06T21:56:51.849Z",
			"display": "block",
			"position": "absolute",
			"left": "0px",
			"right": "auto",
			"width": "333.60925439453126px",
			"top": "239px",
			"bottom": "auto",
			"height": "306.9814875488281px"
		}
	},
	"image1": {
		"kind": "Image",
		"props": {
			"src": "https://uploads.quarkly.io/65c28f65009abe001f02fdd6/images/fourth.png?v=2024-02-06T21:56:51.825Z",
			"display": "block",
			"position": "absolute",
			"left": "241px",
			"right": "auto",
			"width": "402.03112646484374px",
			"top": "215px",
			"bottom": "auto",
			"height": "331.8778839111328px"
		}
	},
	"text1": {
		"kind": "Text",
		"props": {
			"font": "--headline1",
			"margin": "16px 0px 0px 0px",
			"sm-text-align": "center",
			"sm-width": "80%",
			"lg-text-align": "center",
			"lg-font": "--headline2",
			"color": "--light",
			"position": "absolute",
			"top": "305px",
			"right": "50px",
			"bottom": "auto",
			"left": "auto",
			"width": "648.00415625px",
			"height": "97.74816748046874px",
			"children": "Unlock the Future:"
		}
	},
	"image2": {
		"kind": "Image",
		"props": {
			"src": "https://uploads.quarkly.io/65c28f65009abe001f02fdd6/images/first.png?v=2024-02-06T21:56:51.807Z",
			"display": "block",
			"position": "absolute",
			"left": "78px",
			"right": "auto",
			"width": "462.8660888671875px",
			"top": "290px",
			"bottom": "auto",
			"height": "264.2223540039063px"
		}
	},
	"text2": {
		"kind": "Text",
		"props": {
			"sm-text-align": "center",
			"sm-width": "80%",
			"opacity": "0.7",
			"md-text-align": "center",
			"font": "--lead",
			"color": "--light",
			"margin": "10px 0px 35px 0px",
			"position": "absolute",
			"top": "398px",
			"right": "176px",
			"bottom": "auto",
			"left": "auto",
			"width": "412.195px",
			"height": "37.25775146484375px",
			"children": <>
				{" "}Discover, Learn, and Earn with BrainyJars NFTs
			</>
		}
	},
	"link": {
		"kind": "Link",
		"props": {
			"text-decoration-line": "initial",
			"color": "--darkL2",
			"padding": "12px 24px 12px 24px",
			"letter-spacing": "0.5px",
			"transition": "transform --transitionDuration-fast --transitionTimingFunction-easeInOut 0s",
			"href": "#mission",
			"background": "--color-light",
			"font": "--base",
			"hover-transform": "translateY(-4px)",
			"position": "absolute",
			"top": "454px",
			"right": "312px",
			"bottom": "auto",
			"left": "auto",
			"width": "87.0625px",
			"height": "24px",
			"children": "Learn More"
		}
	}
};

const Front = props => {
	const {
		override,
		children,
		rest
	} = useOverrides(props, overrides, defaultProps);
	return <Section {...rest}>
		<Override
			slot="SectionContent"
			md-margin="0px 16px 0px 16px"
			width="100%"
			height="620px"
			justify-content="center"
			sm-width="100%"
			min-width="auto"
			margin="0px 32px 0px 32px"
			align-items="center"
			lg-height="520px"
			md-height="420px"
			md-padding="0px 24px 0px 24px"
		/>
		<Text {...override("text")} />
		<Image {...override("image")} />
		<Image {...override("image1")} />
		<Text {...override("text1")} />
		<Image {...override("image2")} />
		<Text {...override("text2")} />
		<Link {...override("link")} />
		{children}
	</Section>;
};

Object.assign(Front, { ...Section,
	defaultProps,
	overrides
});
export default Front;